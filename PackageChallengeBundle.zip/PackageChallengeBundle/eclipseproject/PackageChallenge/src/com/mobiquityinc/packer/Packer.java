package com.mobiquityinc.packer;

import java.util.List;

import org.apache.log4j.Logger;

import com.mobiquityinc.exception.APIException;
import com.mobiquityinc.util.FileUtil;
import com.mobiquityinc.util.packing.PackingUtil;
/**
 * This is packer class is responsible to process packages and generate final results
 * 
 * @author Vishal Lakhmapurkar
 *
 */
public class Packer {
    private static final Logger log =Logger.getLogger(Packer.class);
	public static String pack(String filePath) throws APIException {
		//initialize empty result string to avoid null pointer exception
		String finalPackingDetails = "";
        //First Step validate and Parse File will return list of packges
		List<com.mobiquityinc.model.Package> packages = FileUtil.validateAndParseFile(filePath);
		//check for empty and null list
		if(packages!=null && !packages.isEmpty())
		{
			finalPackingDetails =PackingUtil.generatePackingDetails(packages);
			
		}
		//return final result as string	
		return finalPackingDetails = (finalPackingDetails!=null?finalPackingDetails:"");
	}

	public static void main(String[] args)  {
		log.debug("Started Packing Process..");
		String filePath ="";
		String result ="";

		if(args.length ==1){
			filePath = args[0];
		}else{

			filePath = "testdata/defaultdata.txt";
			log.warn("Initializing and processing default file : "+filePath);

			log.warn("To start with new file need to pass argument as parameter like USAGE: java com.mobiquityinc.packer.Packer <filePath>");
		}
		try {
			result = pack(filePath);
			log.debug("Final Result: "+result);
		} catch (APIException e) {
			log.fatal("Packing process ended with exception "+e.getMessage(),e);
		}
		
		log.debug("Ended Packing Process..");
		log.debug("Log details logs/PackageChallenge.log");


	}

}
