package com.mobiquityinc.model;

import java.util.List;

public class Package {
private double packageWeight;
private List<Item> items;
public double getPackageWeight() {
	return packageWeight;
}
public void setPackageWeight(double packageWeight) {
	this.packageWeight = packageWeight;
}
public List<Item> getItems() {
	return items;
}
public void setItems(List<Item> items) {
	this.items = items;
}
@Override
public String toString() {
	return "Package [packageWeight=" + packageWeight + ", items=" + items + "]";
}


}
