package com.mobiquityinc.model;

public class Item {
	private int itemIndex;
	private double itemWeight;
	private double itemCost;
	public int getItemIndex() {
		return itemIndex;
	}
	public void setItemIndex(int itemIndex) {
		this.itemIndex = itemIndex;
	}
	public double getItemWeight() {
		return itemWeight;
	}
	public void setItemWeight(double itemWeight) {
		this.itemWeight = itemWeight;
	}
	public double getItemCost() {
		return itemCost;
	}
	public void setItemCost(double itemCost) {
		this.itemCost = itemCost;
	}
	@Override
	public String toString() {
		return "Item [itemIndex=" + itemIndex + ", itemWeight=" + itemWeight + ", itemCost=" + itemCost + "]";
	}
	

}
