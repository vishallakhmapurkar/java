package com.mobiquityinc.util.packing;

import org.apache.log4j.Logger;

import com.mobiquityinc.exception.APIException;
import com.mobiquityinc.model.Package;

public class PackageValidator implements PackageConstraints{
	 
    private static final Logger log =Logger.getLogger(PackageValidator.class);

	public static boolean validatePackage(Package pcg) throws APIException{
		log.debug("Started Validation for Package :");
		
		if(pcg ==null) throw new APIException("Packge should not be NULL");
		if(pcg.getPackageWeight() < 0) throw new APIException("Packge weight should not be less then 0");
		if(pcg.getPackageWeight() > MAX_WEIGHT_PER_PACKAGE) throw new APIException("Packge weight should not be greater then "+MAX_WEIGHT_PER_PACKAGE);
		if(pcg.getItems()==null || pcg.getItems().isEmpty() ) throw new APIException("Packge items should not be NULL or Empty");
		
		log.debug("Ended Validation for Package :");
		return true;
	}
 
 
} 