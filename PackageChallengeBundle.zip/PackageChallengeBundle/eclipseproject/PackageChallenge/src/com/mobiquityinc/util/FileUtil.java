package com.mobiquityinc.util;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.mobiquityinc.exception.APIException;
import com.mobiquityinc.model.Item;
import com.mobiquityinc.util.packing.PackageConstraints;
import com.mobiquityinc.util.packing.PackageValidator;

public class FileUtil implements PackageConstraints {
	private static final Logger log = Logger.getLogger(FileUtil.class);

	public static String COLON = ":";

	public static List<com.mobiquityinc.model.Package> validateAndParseFile(String filePath) throws APIException {
		log.debug("Started Parsing and Validating of file:" + filePath);
		List<com.mobiquityinc.model.Package> rawPackages = new ArrayList<com.mobiquityinc.model.Package>();
		try (BufferedReader in = Files.newBufferedReader(Paths.get(filePath), StandardCharsets.ISO_8859_1)) {
			String line;
			while ((line = in.readLine()) != null) {
				String[] pcgInfo = line.split(COLON);
				com.mobiquityinc.model.Package pcg = new com.mobiquityinc.model.Package();
				pcg.setPackageWeight(Double.parseDouble(pcgInfo[0].trim()));
				String[] items = pcgInfo[1].split("\\s+");
				List<Item> ItemList = new ArrayList<Item>();
				for (String item : items) {
					if (!item.isEmpty()) {
						String[] itemAry = item.trim().replaceAll("[?]", "").replaceAll("\\)", "").replaceAll("\\(", "")
								.split(",");
						if (itemAry.length == 3 && Double.parseDouble(itemAry[1].trim()) <= MAX_WEIGHTANDCOST_PER_ITEM
								&& Double.parseDouble(itemAry[2].trim()) <= MAX_WEIGHTANDCOST_PER_ITEM && ItemList.size()<MAX_ITEM_LIMIT_PER_PACKAGE) {
							Item itmm = new Item();
							itmm.setItemIndex(Integer.parseInt(itemAry[0].trim()));
							itmm.setItemWeight(Double.parseDouble(itemAry[1].trim()));
							itmm.setItemCost(Double.parseDouble(itemAry[2].trim()));
							ItemList.add(itmm);
							pcg.setItems(ItemList);
						} else {
							log.warn("Invalid Item :[Index]:" + Integer.parseInt(itemAry[0].trim()) + ",[Weight]: "
									+ Double.parseDouble(itemAry[1].trim()) + ",[Cost]:"
									+ Double.parseDouble(itemAry[2].trim()) + " , hence skiping this item "
									+ "Note: Max weight and cost for per item is :" + MAX_WEIGHTANDCOST_PER_ITEM);

						}
					}
				}
				try {
					if (PackageValidator.validatePackage(pcg)) {
						log.debug("Package Validation succesfull for Package :"+pcg.toString());

						rawPackages.add(pcg);
					}
				} catch (Exception e) {
					log.warn("Package " + pcg.toString() + " validation error ,hence skipping this,:" + e.getMessage());

				}
			}
		} catch (Exception e) {
			log.error("File " + filePath + " processing error :");
			throw new APIException(e.getMessage(), e);
		}
		log.debug("Ended Parsing and Validating of file:" + filePath);

		return rawPackages;
	}

}
