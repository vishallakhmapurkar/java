package com.mobiquityinc.util.packing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.mobiquityinc.model.Item;

public class PackingUtil {
	static Map<Integer, Double> weightMap =null;
	static Map<Integer, Double> costMap = null;

	public static String generatePackingDetails(List<com.mobiquityinc.model.Package> packages) {
		List<String> res =new ArrayList<String>();
		weightMap = new TreeMap<>();
		costMap = new TreeMap<>();
		for (com.mobiquityinc.model.Package pacg : packages) {
			List<Item> items = pacg.getItems();
			for (Item item : items) {
				if (item.getItemWeight() < pacg.getPackageWeight()) {
					weightMap.put(item.getItemIndex(), item.getItemWeight());
					costMap.put(item.getItemIndex(), item.getItemCost());
				}
			}
			
			res.add(getFinalIndexValues(pacg.getPackageWeight(), weightMap, costMap));
		}
		
		
		return res.toString();
	}
	public static String getFinalIndexValues(double packageWeight,Map<Integer, Double> weightMap,Map<Integer, Double> costMap){
		Set<String> indexSet = new LinkedHashSet<>();
		TreeMap<Double, Double> tempMap = new TreeMap<>();
		TreeMap<Double, Integer> tempCostMap = new TreeMap<>();

		double totalweight = 0;

		while (!weightMap.isEmpty() && !costMap.isEmpty()) {
			double maxCost = Collections.max(costMap.values());
			Integer index = Collections.max(costMap.entrySet(), Map.Entry.comparingByValue()).getKey();
			double weight = weightMap.get(index);
			if(((totalweight + weight) <= packageWeight) || (tempMap.containsKey(maxCost) && (weight < tempMap.get(maxCost)))){
				
				if (tempMap.containsKey(maxCost) && (weight < tempMap.get(maxCost))) {
						totalweight = totalweight - tempMap.get(maxCost);
						indexSet.remove(tempCostMap.get(maxCost)+"");
				}
				indexSet.add(""+index);
				totalweight = totalweight + weight;
				tempCostMap.put(maxCost,index) ;
				tempMap.put(maxCost, weight);
         
            
			}
			weightMap.remove(index);
			costMap.remove(index);
		}
		return String.join(",", indexSet);
	}
	 public static Integer getCostMapKeyWithHighestValue(Map<Integer, Double> map) {
		    Integer keyWithHighestVal = 0;

		    // getting the maximum value in the Hashmap
		    Double maxValueInMap = (Collections.max(map.values()));

		    //iterate through the map to get the key that corresponds to the maximum value in the Hashmap
		    for (Map.Entry<Integer, Double> entry : map.entrySet()) {  // Iterate through hashmap
		        if (entry.getValue() == maxValueInMap) {

		            keyWithHighestVal = entry.getKey();     // this is the key which has the max value
		        }

		    }
		    return keyWithHighestVal;
		}
}
