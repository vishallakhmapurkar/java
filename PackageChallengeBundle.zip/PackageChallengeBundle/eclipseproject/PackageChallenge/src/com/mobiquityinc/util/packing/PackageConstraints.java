package com.mobiquityinc.util.packing;

public interface PackageConstraints {
	
	double MAX_WEIGHT_PER_PACKAGE =100;
	int MAX_ITEM_LIMIT_PER_PACKAGE =15;
	double MAX_WEIGHTANDCOST_PER_ITEM =100;
}
