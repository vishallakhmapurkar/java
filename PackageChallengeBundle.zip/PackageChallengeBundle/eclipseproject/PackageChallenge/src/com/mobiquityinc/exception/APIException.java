package com.mobiquityinc.exception;

public class APIException extends Exception{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public APIException(String message) {
	        super(message);
	    }
	public APIException(String message,Throwable e) {
        super(message,e);
    }
	
	public APIException(Throwable e) {
        super(e);
    }
}
