package com.mobiquityinc.packer.test;

import org.junit.Test;

import com.mobiquityinc.exception.APIException;
import com.mobiquityinc.packer.Packer;
import static org.junit.Assert.assertEquals;

/**
 * Assignment: Package Challenge Introduction You want to send your friend a
 * package with different things. Each thing you put inside the package has such
 * parameters as index number, weight and cost. The package has a weight limit.
 * Your goal is to determine which things to put into the package so that the
 * total weight is less than or equal to the package limit and the total cost is
 * as large as possible. You would prefer to send a package which weights less
 * in case there is more than one package with the same price. Packing Challenge
 * Rule 1. Max weight that a package can take is ≤ 100 2. There might be up to
 * 15 items you need to choose from 3. Max weight and cost of an item is ≤ 100
 * 
 * @author Vishal Lakhmapurkar
 *
 */
public class PackerTest {
	/*
	 * File Name: testdata/filenotexit.txt Result: APIException
	 */
	@Test(expected = APIException.class)
	public void testInvalidFile() throws APIException {
		String file = "testdata/filenotexit.txt";
		Packer.pack(file);

	}

	/*
	 * * 1. Max weight that a package can take is ≤ 100 106 line should ignore
	 * 
	 * File Name: testdata/test_packageweightgreaterthenmaxweight100.txt 91 :
	 * (1,53.38,45) (2,88.62,98) (3,78.48,3) (4,72.30,76) (5,30.18,9)
	 * (6,46.34,48) 25 : (1,85.31,29) (2,14.55,74) (3,3.98,16) (4,26.24,55)
	 * (5,63.69,52) (6,76.25,75) (7,60.02,74) (8,93.18,35) (9,89.95,78) 106 :
	 * (1,90.72,13) (2,33.80,40) (3,43.15,10) (4,37.97,16) (5,46.81,36)
	 * (6,48.77,79) (7,81.80,45) (8,19.36,79) (9,6.76,64) Result: [2, 2,3]
	 */
	@Test
	public void testPackageWeightGreaterThenMaxWeight100() throws APIException {
		String file = "testdata/test_packageweightgreaterthenmaxweight100.txt";
		String result = Packer.pack(file);

		assertEquals("[2, 2,3]", result);

	}

	/*
	 * There might be up to 15 items you need to choose from (16,1,1) item
	 * should ignore
	 * 
	 * File Name: testdata/test_packageweightgreaterthenmaxweight100.txt 16 :
	 * (1,1,1) (2,1,1) (3,1,1) (4,1,1) (5,1,1) (6,1,1) (7,1,1) (8,1,1) (9,1,1)
	 * (10,1,1) (11,1,1) (12,1,1) (13,1,1) (14,1,1) (15,1,1) (16,1,1)
	 * 
	 * Result: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
	 */
	@Test
	public void testMax15ItemsPerPackage() throws APIException {
		String file = "testdata/test_max15item.txt";
		String result = Packer.pack(file);

		assertEquals("[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]", result);

	}

	/*
	 * File:test_maxCostAndWeightItemShoulLessThen100.txt
	 * Max weight and cost of an item is ≤ 100 , then (2,88.62,105) and (1,197,34) item should ignore
	 * 
	 * 81 : (1,53.38,45) (2,88.62,105) 
	 * 8 : (1,197,34)
	 * 
	 * Result: [1]
	 */
	@Test
	public void testMaxCostAndWeightShouldLessThen100OfItem() throws APIException {
		String file = "testdata/test_maxCostAndWeightItemShoulLessThen100.txt";
		String result = Packer.pack(file);

		assertEquals("[1]", result);

	}
}
