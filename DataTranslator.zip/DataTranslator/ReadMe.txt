****Data Translator***
Required Java 8 to run:

Instuction to run:

Modify Config files according to need:
1) data.txt- data file tab delimeted.
For Example:
COL0	COL1	COL2	COL3
ID1	VAL11	VAL12	VAL12
ID2	VAL21	VAL22	VAL23

2) conf1.txt- config file tab delimeted for extract column with labels.
For Example:
COL0	OURID
COL1	OURCOL1
COL3	OURCOL3

2) conf2.txt- config file tab delimeted for extract id data with labels.
For Example:
ID2	OURIDXXX


3) Output file:

Expected output like below:
OURID	OURCOL1		OURCOL3	
				
OURIDXXX	VAL21	VAL23		


Changes need to done according to env:

Open RunDataTranslator.bat file from executable folder in notepad and modify below code:

java -cp DataTranslator.jar com.assetcontrol.main.DataTranslator <path to conf/data.txt> <path to ...conf/conf1.txt> <path to.. /conf/conf2.txt> <path to ../conf/output.txt>


