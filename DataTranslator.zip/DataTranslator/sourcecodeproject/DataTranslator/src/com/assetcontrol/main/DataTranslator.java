/*
 * Author :
 * Vishal Lakhmapurkar:
 * 7/13/2017
 */
package com.assetcontrol.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DataTranslator {

	public static void main(String[] args) {
		if (args.length != 4) {

			System.out.println("See Usage : Please enter in below format");
			System.out.println(
					"java com.assetcontrol.main.DataTranslator <datafile> <colconfigfile> <extractconfigfile> <outfilepath>");
			System.exit(-1);
		}

		BufferedWriter bw = null;
		FileWriter fw = null;
		final String filePath = args[0];// "resourses/data.txt";
		final String conf1 = args[1];// "resourses/conf1.txt";
		final String conf2 = args[2];// "resourses/conf2.txt";
		final String output = args[3];// "resourses/output.txt";
		try {
			System.out.println("Started data translator process");

			String[][] data = createDataMatrixFromFile(filePath);
			Map<String, String> colConfigdata = getConfigMap(conf1);
			Map<String, String> dataNeedToExtract = getConfigMap(conf2);
			fw = new FileWriter(output);
			bw = new BufferedWriter(fw);
			List<Integer> rowNum = new LinkedList<>();
			for (int i = 0; i < data.length; i++) {
				boolean validData = false;
				for (int j = 0; j < data[i].length; j++) {
					if (colConfigdata.containsKey(data[i][j])) {

						bw.write(colConfigdata.get(data[i][j]));
						rowNum.add(j);

					}
					if (dataNeedToExtract.containsKey(data[i][j])) {
						bw.write(dataNeedToExtract.get(data[i][j]));
						validData = true;
					} else if (validData && j < rowNum.size()) {
						bw.write((data[i][rowNum.get(j)]));
					}
					bw.write("\t");
				}
				bw.write("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		System.out.println("Ended data translator process see output file at :"+output);
	}

	static public String[][] createDataMatrixFromFile(String filePath) throws Exception {
		String[][] myArray;

		List<String> lines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);

		myArray = new String[lines.size()][];

		for (int i = 0; i < lines.size(); i++) {
			myArray[i] = lines.get(i).split("\\t+");
		}
		return myArray;
	}

	static public Map<String, String> getConfigMap(String filePath) throws Exception {
		String delimiter = "\\t+";
		Map<String, String> map = new HashMap<>();
		try (BufferedReader in = new BufferedReader(new FileReader(filePath))) {
			String line;
			while ((line = in.readLine()) != null) {
				map.put(line.split(delimiter)[0], line.split(delimiter)[1]);
			}
		} catch (Exception e) {
			throw e;
		}

		return map;
	}
}
